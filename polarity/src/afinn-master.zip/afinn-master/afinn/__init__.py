"""AFINN sentiment analysis."""


from __future__ import absolute_import, division, print_function

from .afinn import Afinn


__all__ = ('Afinn',)
